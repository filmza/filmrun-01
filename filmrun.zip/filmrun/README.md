# Vanilla
Nock em out
